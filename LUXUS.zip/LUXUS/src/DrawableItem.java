import java.awt.Image;
    


public interface DrawableItem extends Item
{
    public Image getImage();
}
